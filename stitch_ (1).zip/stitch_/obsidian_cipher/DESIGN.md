---
name: Obsidian Cipher
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c7c4d8'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#918fa1'
  outline-variant: '#464555'
  surface-tint: '#c3c0ff'
  primary: '#c3c0ff'
  on-primary: '#1d00a5'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#4d44e3'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.05em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system embodies the calculated precision, security, and administrative efficiency of next-generation cryptosystems. Crafted specifically for secure key management, activation licensing, and telemetry observation, the aesthetic merges technical command with executive clarity.

The visual direction draws from high-density cybersecurity consoles and developer infrastructure tooling:
- **Atmosphere:** Deep midnight environments paired with structural wireframe geometry. Interfaces prioritize situational awareness, minimal ocular fatigue during extended shifts, and surgical typographic rhythm.
- **Visual Style:** Precision Dark UI with low-contrast structural outlines, microscopic neon accents (cyan and indigo), and monospaced cryptographic metrics. Surfaces avoid heavy skeuomorphic textures in favor of clean structural tiers, razor-sharp dividers, and subtle directional surface luminosity.
- **Bidirectional Neutrality:** Balanced visual weight across both LTR (English) and RTL (Arabic) rendering. Forms, status indicators, metrics cards, and data sequences preserve spatial hierarchy and immediate scannability regardless of script direction.

## Colors

The palette operates on calibrated low-reflectance foundations offset by sharp structural delineations and luminous signal channels.

### Surface Architecture
- **Base Canvas (`#0B0F19`):** Root background canvas providing maximum contrast for text metrics while suppressing peripheral glare.
- **Surface Elevation 1 (`#111827`):** Primary card, sidebar, and container background.
- **Surface Elevation 2 (`#1F2937`):** Secondary controls, table headers, elevated cards, and modal backplates.
- **Border Default (`#1F2937`):** Default hairline delineation separating data modules without visual clutter.
- **Border Strong (`#374151`):** Active structural borders, hover indicators, table division boundaries, and control perimeters.

### Functional Accents
- **Primary Indigo (`#4F46E5`):** Reserved for high-intent administrative workflows: batch-generation triggers, validation commits, primary CTA buttons, and selected states.
- **Secondary Cyan (`#06B6D4`):** Used for cryptographic signatures, generated string highlights, API endpoints, telemetry links, and data visualizers.
- **Tertiary & Success Emerald (`#10B981`):** Applied exclusively to active license statuses, verified signatures, authenticated nodes, and positive quota metrics.
- **Warning Amber (`#F59E0B`):** Reserved for keys approaching expiration thresholds, rate-limit warnings, and suspended states.
- **Destructive Rose (`#EF4444`):** Expresses revoked certificates, blocked hardware identifiers, and signature mismatches.
- **Text & Foreground:** Primary labels resolve to `#F9FAFB`, secondary captions to `#9CA3AF`, and muted/monospaced metadata to `#6B7280`.

## Typography

Typography prioritizes high legibility under dense administrative conditions and rigorous bilingual symmetry.

- **Headlines (`Geist`):** Delivers clean geometry, crisp horizontal stems, and disciplined proportional spacing for administrative dashboards.
- **Body & Controls (`IBM Plex Sans` / `IBM Plex Sans Arabic`):** Designed to handle dual LTR/RTL contexts seamlessly. In Arabic mode, IBM Plex Sans Arabic replaces the Latin face, maintaining identical baseline proportions, optical weight, and counter shapes without triggering layout shifts.
- **Data & Cryptographic Tokens (`JetBrains Mono`):** Dedicated to license blocks (e.g., `XXXX-XXXX-XXXX-XXXX`), hardware UUIDs, hash digests, timestamps, and API keys. The monospaced family preserves strict tabular alignment across data grids and copy-paste buffers in all locales.

## Layout & Spacing

The layout operates on a compact 4px baseline sub-grid supporting dense telemetry, data grids, and responsive tool panels.

### Grid Architecture
- **Desktop (≥1280px):** 12-column layout with a fixed 260px administrative navigation drawer, fluid content workspace, `gutter-lg` (1.5rem), and `margin-lg` (2rem).
- **Tablet (768px - 1279px):** 8-column layout with a collapsible icon-only navigation rail (64px), `gutter` (1rem), and `margin-md` (1.5rem).
- **Mobile (<768px):** 4-column single-stack arrangement, collapsed overlay drawers, full-width data cards replacing multi-column tables, `gutter` (1rem), and `margin` (1rem).

### Layout Discipline
- Component padding strictly consumes tokens from `space-xs` through `space-2xl`.
- Horizontal padding on data table cells matches `space-lg` (16px), with vertical cell padding restrained to `space-md` (12px) to optimize vertical scanning density.
- Right-to-Left (RTL) mode mirrors structural gutters, flex direction, and column order automatically while preserving left-to-right alignment exclusively for monospaced license codes, UUIDs, and mathematical formulas.

## Elevation & Depth

Visual hierarchy does not rely on heavy drop shadows, which muddy dark interfaces. Depth is achieved through **tonal layering**, **hairline structural borders**, and **subtle illumination gradients**.

### Elevation Tiers
- **Tier 0 (Root Canvas - `#0B0F19`):** Ground level. No shadow, raw background.
- **Tier 1 (Panels & Surface Modules - `#111827`):** Delineated strictly by a `1px solid #1F2937` border. Ambient shadow is ultra-subtle: `0 1px 3px 0 rgba(0, 0, 0, 0.4)`.
- **Tier 2 (Popovers, Flyouts & Dropdowns - `#1F2937`):** Elevated above the canvas with a `1px solid #374151` boundary and focused containment shadow: `0 10px 15px -3px rgba(0, 0, 0, 0.6), 0 4px 6px -4px rgba(0, 0, 0, 0.5)`.
- **Tier 3 (Modals & Key Generation Overlays - `#111827`):** Central floating focus containers framed with `1px solid #374151`, surrounded by a full backdrop blur (`backdrop-filter: blur(8px)`) using `#0B0F19` at 80% opacity. Accented by a very faint directional top highlight: `inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`.

## Shapes

The design system enforces a disciplined, technical shape geometry (`roundedness: 1`). Soft, rounded corners project security-conscious enterprise efficiency without the brutalism of sharp 90-degree corners or the consumer playfulness of pill shapes.

- **Base Radius (`0.25rem` / 4px):** Applied to badges, table tags, small tooltips, checkboxes, segmented controls, and nested sub-elements.
- **Component Radius (`0.375rem` / 6px):** Applied to buttons, inputs, select triggers, search fields, and metric cards.
- **Container Radius (`0.5rem` / 8px):** Applied to root cards, modal dialogs, data table outer containers, and code snippet display blocks.
- **Circular (`9999px`):** Reserved solely for user avatar circles and status beacon indicators (e.g., active telemetry pulse dots).

## Components

### Buttons & Actions
- **Primary:** Background `#4F46E5`, foreground `#FFFFFF`, border `1px solid #6366F1`. On hover, lightens to `#4338CA` with an ambient glow (`box-shadow: 0 0 12px rgba(79, 70, 229, 0.4)`).
- **Secondary / Ghost:** Background `#111827`, foreground `#F9FAFB`, border `1px solid #374151`. Hover shifts background to `#1F2937` and border to `#4B5563`.
- **Destructive:** Background `rgba(239, 68, 68, 0.1)`, foreground `#EF4444`, border `1px solid rgba(239, 68, 68, 0.25)`.
- **Interactive State:** Focus visible displays a dual-offset ring: `2px solid #06B6D4` with `2px` offset colored `#0B0F19`.

### Badges & Status Chips
- Badges use a high-contrast compound design: `1px solid` border, low-opacity background fill (12%), and a bright foreground text color accompanied by an optional 6px beacon dot.
  - **Active / Issued:** Fill `rgba(16, 185, 129, 0.12)`, border `rgba(16, 185, 129, 0.3)`, text `#10B981`.
  - **Expiring / Trial:** Fill `rgba(245, 158, 11, 0.12)`, border `rgba(245, 158, 11, 0.3)`, text `#F59E0B`.
  - **Revoked / Inactive:** Fill `rgba(239, 68, 68, 0.12)`, border `rgba(239, 68, 68, 0.3)`, text `#EF4444`.
  - **Machine Bound:** Fill `rgba(6, 182, 212, 0.12)`, border `rgba(6, 182, 212, 0.3)`, text `#06B6D4`.

### Input Fields & Controls
- **Inputs:** Height `38px`, background `#0B0F19`, border `1px solid #1F2937`, text `#F9FAFB`, typography `body-md`. Placeholder `#4B5563`.
- **Input Focus:** Border transitions instantly to `#06B6D4`, backed by an ambient glow (`0 0 0 1px #06B6D4`).
- **Checkboxes & Radios:** Size `16px`, background `#111827`, border `1px solid #374151`. When checked, background becomes `#4F46E5` with a crisp white tick/dot.

### Data Tables
- Outer frame uses `border: 1px solid #1F2937` and `border-radius: 0.5rem`.
- Header row uses background `#111827`, typography `label-sm` with uppercase letter spacing, text color `#9CA3AF`, and a lower divider border `1px solid #1F2937`.
- Rows use zebra hover effect: base state `#0B0F19`, hover state `#111827`. Cell dividers use `1px solid #1F2937`.
- Columns containing license codes, hashes, or IPs are styled with `code-md` font and text `#06B6D4`.

### Code Generator Modal & Display Panels
- **Key Output Display:** Large monospace display block with background `#0B0F19`, border `1px dashed #374151`, and interior padding `space-lg`. Text styled with `code-lg` in `#06B6D4`.
- **Integrated Actions:** Inline "Copy" and "Verify" action buttons anchored on the trailing side (right in LTR, left in RTL) with quick-feedback tooltips.
- **Entropy & Parameter Sliders:** Track filled with `#4F46E5`, thumb sized at `16px` finished with a solid `#06B6D4` ring.

### Metric / KPI Cards
- Base background `#111827`, border `1px solid #1F2937`, inner padding `space-xl`.
- Layout: Top row hosts micro-label (`label-sm` in `#9CA3AF`) and contextual category icon. Middle row displays primary metric (`display` or `headline-lg` in `#F9FAFB`). Bottom row embeds delta sparklines or percentage growth badges.